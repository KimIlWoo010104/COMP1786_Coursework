package com.example.test_yoga;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddInstanceActivity extends Activity {
    private EditText etDate, etTeacher, etComments;
    private Button btnSubmit;
    private YogaDBHelper dbHelper;
    private long courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_instance);

        dbHelper = new YogaDBHelper(this);
        courseId = getIntent().getLongExtra("COURSE_ID", -1);

        etDate = findViewById(R.id.etDate);
        etTeacher = findViewById(R.id.etTeacher);
        etComments = findViewById(R.id.etComments);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addClassInstance();
            }
        });
    }

    private void addClassInstance() {
        String date = etDate.getText().toString().trim();
        String teacher = etTeacher.getText().toString().trim();
        String comments = etComments.getText().toString().trim();

        if (date.isEmpty() || teacher.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }

        ClassInstance instance = new ClassInstance();
        instance.setCourseId(courseId);
        instance.setDate(date);
        instance.setTeacher(teacher);
        instance.setComments(comments);

        long id = dbHelper.addClassInstance(instance);
        if (id != -1) {
            Toast.makeText(this, "Class instance added successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to add class instance", Toast.LENGTH_SHORT).show();
        }
    }
}