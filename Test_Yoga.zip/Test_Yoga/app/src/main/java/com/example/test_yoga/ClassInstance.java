package com.example.test_yoga;

public class ClassInstance {
    private long id;
    private long courseId;
    private String date;
    private String teacher;
    private String comments;

    // Getters and setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getCourseId() { return courseId; }
    public void setCourseId(long courseId) { this.courseId = courseId; }
    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
    public String getTeacher() { return teacher; }
    public void setTeacher(String teacher) { this.teacher = teacher; }
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
}
