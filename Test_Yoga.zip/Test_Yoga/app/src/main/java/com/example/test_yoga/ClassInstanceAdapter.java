package com.example.test_yoga;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ClassInstanceAdapter extends ArrayAdapter<ClassInstance> {
    public ClassInstanceAdapter(Context context, List<ClassInstance> instances) {
        super(context, R.layout.list_item_instance, instances);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ClassInstance instance = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item_instance, parent, false);
        }

        TextView tvDate = convertView.findViewById(R.id.tvDate);
        TextView tvTeacher = convertView.findViewById(R.id.tvTeacher);
        TextView tvComments = convertView.findViewById(R.id.tvComments);

        tvDate.setText(instance.getDate());
        tvTeacher.setText("Teacher: " + instance.getTeacher());
        tvComments.setText(instance.getComments() != null ?
                instance.getComments() : "No additional comments");

        return convertView;
    }
}
