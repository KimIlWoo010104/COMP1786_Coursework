package com.example.test_yoga;

import android.content.Context;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CloudSync {
    private final DatabaseReference dbRealtime;
    private final Context context;
    private final YogaDBHelper dbHelper;

    public CloudSync(Context context) {
        this.context = context;
        this.dbHelper = new YogaDBHelper(context);
        // Initialize Realtime Database by using URL
        this.dbRealtime = FirebaseDatabase.getInstance("https://courseworkyoga-default-rtdb.firebaseio.com/").getReference();
    }

    public void syncData() {
        syncCoursesToCloud();
    }

    private void syncCoursesToCloud() {
        List<YogaCourse> courses = dbHelper.getAllCourses();
        for (YogaCourse course : courses) {
            syncCourseToRealtimeDB(course);
        }
        Toast.makeText(context, "Syncing courses to Realtime Database...", Toast.LENGTH_SHORT).show();
    }

    private void syncCourseToRealtimeDB(YogaCourse course) {
        Map<String, Object> courseData = new HashMap<>();
        courseData.put("day", course.getDay());
        courseData.put("time", course.getTime());
        courseData.put("capacity", course.getCapacity());
        courseData.put("duration", course.getDuration());
        courseData.put("price", course.getPrice());
        courseData.put("type", course.getType());
        courseData.put("description", course.getDescription() != null ? course.getDescription() : "");
        courseData.put("location", course.getLocation() != null ? course.getLocation() : "");

        dbRealtime.child("yoga_courses")
                .child(String.valueOf(course.getId()))
                .setValue(courseData)
                .addOnSuccessListener(aVoid -> syncInstancesForCourse(course))
                .addOnFailureListener(e ->
                        Toast.makeText(context, "Failed to sync course: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }

    private void syncInstancesForCourse(YogaCourse course) {
        List<ClassInstance> instances = dbHelper.getInstancesForCourse(course.getId());
        for (ClassInstance instance : instances) {
            syncInstanceToRealtimeDB(instance);
        }
    }

    private void syncInstanceToRealtimeDB(ClassInstance instance) {
        Map<String, Object> instanceData = new HashMap<>();
        instanceData.put("date", instance.getDate());
        instanceData.put("teacher", instance.getTeacher());
        instanceData.put("comments", instance.getComments() != null ? instance.getComments() : "");
        instanceData.put("courseId", instance.getCourseId());

        dbRealtime.child("yoga_instances")
                .child(String.valueOf(instance.getId()))
                .setValue(instanceData)
                .addOnFailureListener(e ->
                        Toast.makeText(context, "Failed to sync instance: " + e.getMessage(),
                                Toast.LENGTH_SHORT).show());
    }

}