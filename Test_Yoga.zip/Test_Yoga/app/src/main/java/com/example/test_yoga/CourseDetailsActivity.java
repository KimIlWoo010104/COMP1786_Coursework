package com.example.test_yoga;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;

public class CourseDetailsActivity extends Activity {
    private TextView tvDay, tvTime, tvCapacity, tvDuration, tvPrice, tvType, tvDescription, tvLocation;
    private Button btnAddInstance, btnViewInstances, btnDeleteCourse, btnEditCourse;
    private YogaDBHelper dbHelper;
    private long courseId;

    private static final int EDIT_COURSE_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        dbHelper = new YogaDBHelper(this);
        courseId = getIntent().getLongExtra("COURSE_ID", -1);

        tvDay = findViewById(R.id.tvDay);
        tvTime = findViewById(R.id.tvTime);
        tvCapacity = findViewById(R.id.tvCapacity);
        tvDuration = findViewById(R.id.tvDuration);
        tvPrice = findViewById(R.id.tvPrice);
        tvType = findViewById(R.id.tvType);
        tvDescription = findViewById(R.id.tvDescription);
        tvLocation = findViewById(R.id.tvLocation);
        btnAddInstance = findViewById(R.id.btnAddInstance);
        btnViewInstances = findViewById(R.id.btnViewInstances);
        btnDeleteCourse = findViewById(R.id.btnDeleteCourse);
        btnEditCourse = findViewById(R.id.btnEditCourse);

        loadCourseDetails();

        btnAddInstance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CourseDetailsActivity.this, AddInstanceActivity.class);
                intent.putExtra("COURSE_ID", courseId);
                startActivity(intent);
            }
        });

        btnViewInstances.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CourseDetailsActivity.this, ViewInstancesActivity.class);
                intent.putExtra("COURSE_ID", courseId);
                startActivity(intent);
            }
        });

        btnDeleteCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeleteCourseDialog();
            }
        });

        btnEditCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CourseDetailsActivity.this, EditCourseActivity.class);
                intent.putExtra("COURSE_ID", courseId);
                startActivityForResult(intent, EDIT_COURSE_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EDIT_COURSE_REQUEST && resultCode == RESULT_OK) {
            loadCourseDetails();
            Toast.makeText(this, "Course updated successfully", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadCourseDetails() {
        YogaCourse course = dbHelper.getCourse(courseId);
        if (course != null) {
            tvDay.setText("Day: " + course.getDay());
            tvTime.setText("Time: " + course.getTime());
            tvCapacity.setText("Capacity: " + course.getCapacity());
            tvDuration.setText("Duration: " + course.getDuration() + " minutes");
            tvPrice.setText("Price: £" + course.getPrice());
            tvType.setText("Type: " + course.getType());
            tvDescription.setText("Description: " + (course.getDescription() != null ? course.getDescription() : "N/A"));
            tvLocation.setText("Location: " + (course.getLocation() != null ? course.getLocation() : "N/A"));
        }
    }

    private void showDeleteCourseDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Delete Course")
                .setMessage("Are you sure you want to delete this course and all its scheduled instances?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        deleteCourse();
                    }
                })
                .setNegativeButton("Cancel", null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }

    private void deleteCourse() {
        if (dbHelper.deleteCourse(courseId)) {
            Toast.makeText(this, "Course deleted successfully", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Failed to delete course", Toast.LENGTH_SHORT).show();
        }
    }
}