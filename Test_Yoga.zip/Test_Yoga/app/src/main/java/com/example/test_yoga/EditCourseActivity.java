package com.example.test_yoga;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditCourseActivity extends Activity {
    private EditText etDay, etTime, etCapacity, etDuration, etPrice, etType, etDescription, etLocation;
    private Button btnSave;
    private YogaDBHelper dbHelper;
    private long courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course);

        dbHelper = new YogaDBHelper(this);
        courseId = getIntent().getLongExtra("COURSE_ID", -1);

        // Initialize views
        etDay = findViewById(R.id.etDay);
        etTime = findViewById(R.id.etTime);
        etCapacity = findViewById(R.id.etCapacity);
        etDuration = findViewById(R.id.etDuration);
        etPrice = findViewById(R.id.etPrice);
        etType = findViewById(R.id.etType);
        etDescription = findViewById(R.id.etDescription);
        etLocation = findViewById(R.id.etLocation);
        btnSave = findViewById(R.id.btnSave);

        loadCourseData();

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCourseChanges();
            }
        });
    }

    private void loadCourseData() {
        YogaCourse course = dbHelper.getCourse(courseId);
        if (course != null) {
            etDay.setText(course.getDay());
            etTime.setText(course.getTime());
            etCapacity.setText(String.valueOf(course.getCapacity()));
            etDuration.setText(String.valueOf(course.getDuration()));
            etPrice.setText(String.valueOf(course.getPrice()));
            etType.setText(course.getType());
            etDescription.setText(course.getDescription());
            etLocation.setText(course.getLocation());
        }
    }

    private void saveCourseChanges() {
        YogaCourse course = new YogaCourse();
        course.setId(courseId);
        course.setDay(etDay.getText().toString());
        course.setTime(etTime.getText().toString());
        course.setCapacity(Integer.parseInt(etCapacity.getText().toString()));
        course.setDuration(Integer.parseInt(etDuration.getText().toString()));
        course.setPrice(Double.parseDouble(etPrice.getText().toString()));
        course.setType(etType.getText().toString());
        course.setDescription(etDescription.getText().toString());
        course.setLocation(etLocation.getText().toString());

        if (dbHelper.updateCourse(course)) {
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(this, "Failed to update course", Toast.LENGTH_SHORT).show();
        }
    }
}