package com.example.test_yoga;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.List;

public class InstanceAdapter extends ArrayAdapter<ClassInstance> {
    private final Context context;
    private final YogaDBHelper dbHelper;
    private final CloudSync cloudSync;

    public InstanceAdapter(Context context, List<ClassInstance> instances) {
        super(context, R.layout.list_item_instance, instances);
        this.context = context;
        this.dbHelper = new YogaDBHelper(context);
        this.cloudSync = new CloudSync(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ClassInstance instance = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(context)
                    .inflate(R.layout.list_item_instance, parent, false);
        }

        TextView tvDate = convertView.findViewById(R.id.tvDate);
        TextView tvTeacher = convertView.findViewById(R.id.tvTeacher);
        TextView tvComments = convertView.findViewById(R.id.tvComments);
        Button btnEdit = convertView.findViewById(R.id.btnEdit);
        Button btnDelete = convertView.findViewById(R.id.btnDelete);

        // Display existing data
        tvDate.setText(instance.getDate());
        tvTeacher.setText(instance.getTeacher());
        tvComments.setText(instance.getComments() != null ? instance.getComments() : "No comments");

        // edit button
        btnEdit.setOnClickListener(v -> {
            showEditDialog(instance);
        });

        // Set up delete button
        btnDelete.setOnClickListener(v -> {
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Delete")
                    .setMessage("Delete this class instance?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        if (dbHelper.deleteClassInstance(instance.getId())) {
                            cloudSync.syncData();
                            remove(instance);
                            notifyDataSetChanged();
                            Toast.makeText(context, "Instance deleted", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        return convertView;
    }

    private void showEditDialog(ClassInstance instance) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view = LayoutInflater.from(context).inflate(R.layout.dialog_edit_instance, null);
        builder.setView(view);

        EditText etDate = view.findViewById(R.id.etDate);
        EditText etTeacher = view.findViewById(R.id.etTeacher);
        EditText etComments = view.findViewById(R.id.etComments);
        Button btnSave = view.findViewById(R.id.btnSave);

        // Populate fields with current data
        etDate.setText(instance.getDate());
        etTeacher.setText(instance.getTeacher());
        etComments.setText(instance.getComments());

        AlertDialog dialog = builder.create();

        btnSave.setOnClickListener(v -> {
            // Update instance
            instance.setDate(etDate.getText().toString());
            instance.setTeacher(etTeacher.getText().toString());
            instance.setComments(etComments.getText().toString());


            if (dbHelper.updateInstance(instance)) {
                cloudSync.syncData();
                notifyDataSetChanged();
                Toast.makeText(context, "Instance updated", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}