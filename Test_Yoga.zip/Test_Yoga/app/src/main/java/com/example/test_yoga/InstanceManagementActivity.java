package com.example.test_yoga;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;


public class InstanceManagementActivity extends Activity {
    private ListView lvInstances;
    private YogaDBHelper dbHelper;
    private long courseId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instance_management);

        dbHelper = new YogaDBHelper(this);
        courseId = getIntent().getLongExtra("COURSE_ID", -1);

        lvInstances = findViewById(R.id.lvInstances);
        loadInstances();

        Button btnAddInstance = findViewById(R.id.btnAddInstance);
        btnAddInstance.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddInstanceActivity.class);
            intent.putExtra("COURSE_ID", courseId);
            startActivity(intent);
        });
    }

    private void loadInstances() {
        List<ClassInstance> instances = dbHelper.getInstancesForCourse(courseId);
        InstanceAdapter adapter = new InstanceAdapter(this, instances);
        lvInstances.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadInstances();
    }
}