package com.example.test_yoga;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.widget.SearchView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;

public class MainActivity extends Activity {
    private ListView lvCourses;
    private Button btnAddCourse, btnSearch, btnReset, btnSync;
    private YogaDBHelper dbHelper;
    private CloudSync cloudSync;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseApp.initializeApp(this);
        cloudSync = new CloudSync(this);
        dbHelper = new YogaDBHelper(this);

        // Initialize views
        lvCourses = findViewById(R.id.lvCourses);
        btnAddCourse = findViewById(R.id.btnAddCourse);
        btnSearch = findViewById(R.id.btnSearch);
        btnReset = findViewById(R.id.btnReset);
        btnSync = findViewById(R.id.btnSync);

        // Set click listeners
        btnAddCourse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddCourseActivity.class));
            }
        });

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showResetConfirmationDialog();
            }
        });

        btnSync.setOnClickListener(v -> syncWithCloud());

        lvCourses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                YogaCourse course = (YogaCourse) parent.getItemAtPosition(position);
                openCourseDetails(course.getId());
            }
        });
    }



    private void showResetConfirmationDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Reset Database")
                .setMessage("Are you sure you want to delete all data?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dbHelper.resetDatabase();
                        Toast.makeText(MainActivity.this, "Database reset", Toast.LENGTH_SHORT).show();
                        loadCourses();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void syncWithCloud() {
        // Show sync in progress
        Toast.makeText(this, "Syncing with cloud...", Toast.LENGTH_SHORT).show();
        cloudSync.syncData();
    }

    private void openCourseDetails(long courseId) {
        Intent intent = new Intent(this, CourseDetailsActivity.class);
        intent.putExtra("COURSE_ID", courseId);
        startActivity(intent);
    }

    private void loadCourses() {
        // Create the adapter to convert the array to views
        YogaCourseAdapter adapter = new YogaCourseAdapter(this, dbHelper.getAllCourses());

        // Attach the adapter to the ListView
        lvCourses.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCourses();
    }
}