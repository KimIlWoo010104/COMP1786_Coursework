package com.example.test_yoga;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.List;

public class SearchActivity extends Activity {
    private EditText etSearch;
    private RadioGroup rgSearchType;
    private RadioButton rbTeacher, rbDay, rbDate;
    private Button btnSearch;
    private ListView lvResults;
    private YogaDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        dbHelper = new YogaDBHelper(this);

        etSearch = findViewById(R.id.etSearch);
        rgSearchType = findViewById(R.id.rgSearchType);
        rbTeacher = findViewById(R.id.rbTeacher);
        rbDay = findViewById(R.id.rbDay);
        rbDate = findViewById(R.id.rbDate);
        btnSearch = findViewById(R.id.btnSearch);
        lvResults = findViewById(R.id.lvResults);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performSearch();
            }
        });
    }

    private void performSearch() {
        String query = etSearch.getText().toString().trim();
        if (query.isEmpty()) {
            Toast.makeText(this, "Please enter search term", Toast.LENGTH_SHORT).show();
            return;
        }

        int selectedId = rgSearchType.getCheckedRadioButtonId();
        List<ClassInstance> results = null;

        if (selectedId == R.id.rbTeacher) {
            results = dbHelper.searchByTeacher(query);
            displayInstances(results);
        } else if (selectedId == R.id.rbDay) {
            results = dbHelper.searchByDay(query);
            displayInstances(results);
        } else if (selectedId == R.id.rbDate) {
            results = dbHelper.searchByDate(query);
            displayInstances(results);
        }

        if (results == null || results.isEmpty()) {
            Toast.makeText(this, "No results found", Toast.LENGTH_SHORT).show();
        }
    }

    private void displayInstances(List<ClassInstance> instances) {
        ClassInstanceAdapter adapter = new ClassInstanceAdapter(this, instances);
        lvResults.setAdapter(adapter);
    }
}