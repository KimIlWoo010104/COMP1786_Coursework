package com.example.test_yoga;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class ViewInstancesActivity extends Activity {
    private ListView lvInstances;
    private TextView tvCourseInfo, tvEmpty;
    private Button btnAddInstance;
    private YogaDBHelper dbHelper;
    private long courseId;
    private YogaCourse course;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_instances);

        // Initialize views
        lvInstances = findViewById(R.id.lvInstances);
        tvCourseInfo = findViewById(R.id.tvCourseInfo);
        tvEmpty = findViewById(R.id.tvEmpty);
        btnAddInstance = findViewById(R.id.btnAddInstance);

        // Get course ID from intent
        courseId = getIntent().getLongExtra("COURSE_ID", -1);
        dbHelper = new YogaDBHelper(this);
        course = dbHelper.getCourse(courseId);

        // Set up UI
        setupCourseInfo();
        setupListView();
        setupButtons();
    }

    private void setupCourseInfo() {
        if (course != null) {
            String info = String.format("%s - %s at %s",
                    course.getType(), course.getDay(), course.getTime());
            tvCourseInfo.setText(info);
        }
    }

    private void setupListView() {
        List<ClassInstance> instances = dbHelper.getInstancesForCourse(courseId);

        if (instances.isEmpty()) {
            tvEmpty.setVisibility(View.VISIBLE);
            lvInstances.setVisibility(View.GONE);
        } else {
            tvEmpty.setVisibility(View.GONE);
            lvInstances.setVisibility(View.VISIBLE);

            InstanceAdapter adapter = new InstanceAdapter(this, instances);
            lvInstances.setAdapter(adapter);

            // Set long click listener for deletion
            lvInstances.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    ClassInstance instance = (ClassInstance) parent.getItemAtPosition(position);
                    showDeleteDialog(instance);
                    return true;
                }
            });
        }
    }

    private void setupButtons() {
        btnAddInstance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewInstancesActivity.this, AddInstanceActivity.class);
                intent.putExtra("COURSE_ID", courseId);
                startActivity(intent);
            }
        });
    }

    private void showDeleteDialog(final ClassInstance instance) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Instance")
                .setMessage("Delete class on " + instance.getDate() + "?")
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        if (dbHelper.deleteClassInstance(instance.getId())) {
                            Toast.makeText(ViewInstancesActivity.this,
                                    "Instance deleted",
                                    Toast.LENGTH_SHORT).show();
                            setupListView(); // Refresh the list
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        setupListView(); // Refresh when returning from AddInstanceActivity
    }
}