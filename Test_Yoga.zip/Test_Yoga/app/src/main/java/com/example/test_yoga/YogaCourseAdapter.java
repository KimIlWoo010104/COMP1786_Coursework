package com.example.test_yoga;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class YogaCourseAdapter extends ArrayAdapter<YogaCourse> {

    public YogaCourseAdapter(Context context, List<YogaCourse> courses) {
        super(context, 0, courses);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        YogaCourse course = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.list_item_course, parent, false);
        }

        // Lookup view for data population
        TextView tvTitle = convertView.findViewById(R.id.tvCourseTitle);
        TextView tvDetails = convertView.findViewById(R.id.tvCourseDetails);
        TextView tvPrice = convertView.findViewById(R.id.tvCoursePrice);

        // Populate the data into the template view using the data object
        tvTitle.setText(course.getType());
        tvDetails.setText(String.format("%s at %s (%d mins)",
                course.getDay(), course.getTime(), course.getDuration()));
        tvPrice.setText(String.format("£%.2f per session", course.getPrice()));

        // Return the completed view to render on screen
        return convertView;
    }
}
