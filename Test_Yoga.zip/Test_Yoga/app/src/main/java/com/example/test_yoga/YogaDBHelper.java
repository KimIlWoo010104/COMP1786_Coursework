package com.example.test_yoga;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class YogaDBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "YogaApp.db";
    private static final int DATABASE_VERSION = 1;

    // Courses table and columns
    private static final String TABLE_COURSES = "courses";
    private static final String COLUMN_COURSE_ID = "course_id";
    private static final String COLUMN_DAY = "day";
    private static final String COLUMN_TIME = "time";
    private static final String COLUMN_CAPACITY = "capacity";
    private static final String COLUMN_DURATION = "duration";
    private static final String COLUMN_PRICE = "price";
    private static final String COLUMN_TYPE = "type";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_LOCATION = "location";

    // Class instances table and columns
    private static final String TABLE_INSTANCES = "class_instances";
    private static final String COLUMN_INSTANCE_ID = "instance_id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_TEACHER = "teacher";
    private static final String COLUMN_COMMENTS = "comments";

    // Column index constants for courses table
    private static final int IDX_COURSE_ID = 0;
    private static final int IDX_DAY = 1;
    private static final int IDX_TIME = 2;
    private static final int IDX_CAPACITY = 3;
    private static final int IDX_DURATION = 4;
    private static final int IDX_PRICE = 5;
    private static final int IDX_TYPE = 6;
    private static final int IDX_DESCRIPTION = 7;
    private static final int IDX_LOCATION = 8;

    // Column index constants for instances table
    private static final int IDX_INSTANCE_ID = 0;
    private static final int IDX_INST_COURSE_ID = 1;
    private static final int IDX_DATE = 2;
    private static final int IDX_TEACHER = 3;
    private static final int IDX_COMMENTS = 4;

    public YogaDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_COURSES_TABLE = "CREATE TABLE " + TABLE_COURSES + "("
                + COLUMN_COURSE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DAY + " TEXT NOT NULL,"
                + COLUMN_TIME + " TEXT NOT NULL,"
                + COLUMN_CAPACITY + " INTEGER NOT NULL,"
                + COLUMN_DURATION + " INTEGER NOT NULL,"
                + COLUMN_PRICE + " REAL NOT NULL,"
                + COLUMN_TYPE + " TEXT NOT NULL,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_LOCATION + " TEXT"
                + ")";
        db.execSQL(CREATE_COURSES_TABLE);

        String CREATE_INSTANCES_TABLE = "CREATE TABLE " + TABLE_INSTANCES + "("
                + COLUMN_INSTANCE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_COURSE_ID + " INTEGER NOT NULL,"
                + COLUMN_DATE + " TEXT NOT NULL,"
                + COLUMN_TEACHER + " TEXT NOT NULL,"
                + COLUMN_COMMENTS + " TEXT,"
                + "FOREIGN KEY(" + COLUMN_COURSE_ID + ") REFERENCES " + TABLE_COURSES + "(" + COLUMN_COURSE_ID + ")"
                + ")";
        db.execSQL(CREATE_INSTANCES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INSTANCES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_COURSES);
        onCreate(db);
    }

    public long addCourse(YogaCourse course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAY, course.getDay());
        values.put(COLUMN_TIME, course.getTime());
        values.put(COLUMN_CAPACITY, course.getCapacity());
        values.put(COLUMN_DURATION, course.getDuration());
        values.put(COLUMN_PRICE, course.getPrice());
        values.put(COLUMN_TYPE, course.getType());
        values.put(COLUMN_DESCRIPTION, course.getDescription());
        values.put(COLUMN_LOCATION, course.getLocation());

        long id = db.insert(TABLE_COURSES, null, values);
        db.close();
        return id;
    }

    public YogaCourse getCourse(long courseId) {
        String[] columns = {
                COLUMN_COURSE_ID,
                COLUMN_DAY,
                COLUMN_TIME,
                COLUMN_CAPACITY,
                COLUMN_DURATION,
                COLUMN_PRICE,
                COLUMN_TYPE,
                COLUMN_DESCRIPTION,
                COLUMN_LOCATION
        };

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COURSES,
                columns,
                COLUMN_COURSE_ID + "=?",
                new String[]{String.valueOf(courseId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            YogaCourse course = new YogaCourse();
            course.setId(cursor.getLong(IDX_COURSE_ID));
            course.setDay(cursor.getString(IDX_DAY));
            course.setTime(cursor.getString(IDX_TIME));
            course.setCapacity(cursor.getInt(IDX_CAPACITY));
            course.setDuration(cursor.getInt(IDX_DURATION));
            course.setPrice(cursor.getDouble(IDX_PRICE));
            course.setType(cursor.getString(IDX_TYPE));
            course.setDescription(cursor.getString(IDX_DESCRIPTION));
            course.setLocation(cursor.getString(IDX_LOCATION));
            cursor.close();
            return course;
        }
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }

    public List<YogaCourse> getAllCourses() {
        List<YogaCourse> courses = new ArrayList<>();
        String[] columns = {
                COLUMN_COURSE_ID,
                COLUMN_DAY,
                COLUMN_TIME,
                COLUMN_CAPACITY,
                COLUMN_DURATION,
                COLUMN_PRICE,
                COLUMN_TYPE,
                COLUMN_DESCRIPTION,
                COLUMN_LOCATION
        };

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_COURSES,
                columns,
                null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                YogaCourse course = new YogaCourse();
                course.setId(cursor.getLong(IDX_COURSE_ID));
                course.setDay(cursor.getString(IDX_DAY));
                course.setTime(cursor.getString(IDX_TIME));
                course.setCapacity(cursor.getInt(IDX_CAPACITY));
                course.setDuration(cursor.getInt(IDX_DURATION));
                course.setPrice(cursor.getDouble(IDX_PRICE));
                course.setType(cursor.getString(IDX_TYPE));
                course.setDescription(cursor.getString(IDX_DESCRIPTION));
                course.setLocation(cursor.getString(IDX_LOCATION));
                courses.add(course);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return courses;
    }

    public long addClassInstance(ClassInstance instance) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_COURSE_ID, instance.getCourseId());
        values.put(COLUMN_DATE, instance.getDate());
        values.put(COLUMN_TEACHER, instance.getTeacher());
        values.put(COLUMN_COMMENTS, instance.getComments());

        long id = db.insert(TABLE_INSTANCES, null, values);
        db.close();
        return id;
    }

    public boolean deleteCourse(long courseId) {
        SQLiteDatabase db = this.getWritableDatabase();

        // First delete all instances of this course
        db.delete(TABLE_INSTANCES,
                COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(courseId)});

        // Then delete the course itself
        int rowsDeleted = db.delete(TABLE_COURSES,
                COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(courseId)});
        db.close();

        return rowsDeleted > 0;
    }

    public boolean updateInstance(ClassInstance instance) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, instance.getDate());
        values.put(COLUMN_TEACHER, instance.getTeacher());
        values.put(COLUMN_COMMENTS, instance.getComments());

        int rowsAffected = db.update(TABLE_INSTANCES, values,
                COLUMN_INSTANCE_ID + "=?",
                new String[]{String.valueOf(instance.getId())});

        db.close();
        return rowsAffected > 0;
    }

    // Delete a single class instance
    public boolean deleteClassInstance(long instanceId) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_INSTANCES,
                COLUMN_INSTANCE_ID + " = ?",
                new String[]{String.valueOf(instanceId)});
        db.close();

        return rowsDeleted > 0;
    }

    public List<ClassInstance> getInstancesForCourse(long courseId) {
        List<ClassInstance> instances = new ArrayList<>();
        String[] columns = {
                COLUMN_INSTANCE_ID,
                COLUMN_COURSE_ID,
                COLUMN_DATE,
                COLUMN_TEACHER,
                COLUMN_COMMENTS
        };

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INSTANCES,
                columns,
                COLUMN_COURSE_ID + "=?",
                new String[]{String.valueOf(courseId)},
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                ClassInstance instance = new ClassInstance();
                instance.setId(cursor.getLong(IDX_INSTANCE_ID));
                instance.setCourseId(cursor.getLong(IDX_INST_COURSE_ID));
                instance.setDate(cursor.getString(IDX_DATE));
                instance.setTeacher(cursor.getString(IDX_TEACHER));
                instance.setComments(cursor.getString(IDX_COMMENTS));
                instances.add(instance);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return instances;
    }

    public List<ClassInstance> searchByTeacher(String teacherName) {
        List<ClassInstance> instances = new ArrayList<>();
        String[] columns = {
                COLUMN_INSTANCE_ID,
                COLUMN_COURSE_ID,
                COLUMN_DATE,
                COLUMN_TEACHER,
                COLUMN_COMMENTS
        };

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INSTANCES,
                columns,
                COLUMN_TEACHER + " LIKE ?",
                new String[]{"%" + teacherName + "%"},
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                ClassInstance instance = new ClassInstance();
                instance.setId(cursor.getLong(IDX_INSTANCE_ID));
                instance.setCourseId(cursor.getLong(IDX_INST_COURSE_ID));
                instance.setDate(cursor.getString(IDX_DATE));
                instance.setTeacher(cursor.getString(IDX_TEACHER));
                instance.setComments(cursor.getString(IDX_COMMENTS));
                instances.add(instance);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return instances;
    }

    public List<ClassInstance> searchByDay(String day) {
        List<ClassInstance> instances = new ArrayList<>();
        String query = "SELECT i.* FROM " + TABLE_INSTANCES + " i " +
                "JOIN " + TABLE_COURSES + " c ON i." + COLUMN_COURSE_ID + " = c." + COLUMN_COURSE_ID + " " +
                "WHERE c." + COLUMN_DAY + " LIKE ?";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, new String[]{"%" + day + "%"});

        if (cursor.moveToFirst()) {
            do {
                ClassInstance instance = new ClassInstance();
                instance.setId(cursor.getLong(IDX_INSTANCE_ID));
                instance.setCourseId(cursor.getLong(IDX_INST_COURSE_ID));
                instance.setDate(cursor.getString(IDX_DATE));
                instance.setTeacher(cursor.getString(IDX_TEACHER));
                instance.setComments(cursor.getString(IDX_COMMENTS));
                instances.add(instance);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return instances;
    }

    public List<ClassInstance> searchByDate(String date) {
        List<ClassInstance> instances = new ArrayList<>();
        String[] columns = {
                COLUMN_INSTANCE_ID,
                COLUMN_COURSE_ID,
                COLUMN_DATE,
                COLUMN_TEACHER,
                COLUMN_COMMENTS
        };

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INSTANCES,
                columns,
                COLUMN_DATE + " LIKE ?",
                new String[]{"%" + date + "%"},
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                ClassInstance instance = new ClassInstance();
                instance.setId(cursor.getLong(IDX_INSTANCE_ID));
                instance.setCourseId(cursor.getLong(IDX_INST_COURSE_ID));
                instance.setDate(cursor.getString(IDX_DATE));
                instance.setTeacher(cursor.getString(IDX_TEACHER));
                instance.setComments(cursor.getString(IDX_COMMENTS));
                instances.add(instance);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return instances;
    }

    public void resetDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_INSTANCES);
        db.execSQL("DELETE FROM " + TABLE_COURSES);
        db.close();
    }

    public boolean updateCourse(YogaCourse course) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DAY, course.getDay());
        values.put(COLUMN_TIME, course.getTime());
        values.put(COLUMN_CAPACITY, course.getCapacity());
        values.put(COLUMN_DURATION, course.getDuration());
        values.put(COLUMN_PRICE, course.getPrice());
        values.put(COLUMN_TYPE, course.getType());
        values.put(COLUMN_DESCRIPTION, course.getDescription());
        values.put(COLUMN_LOCATION, course.getLocation());

        // Updating row
        int rowsAffected = db.update(TABLE_COURSES,
                values,
                COLUMN_COURSE_ID + " = ?",
                new String[]{String.valueOf(course.getId())});

        db.close();

        return rowsAffected > 0;
    }
}